const Report = require("../models/Report");
const createCsvWriter = require("csv-writer").createObjectCsvWriter;
const ExcelJS = require("exceljs");
const { errorLogger } = require('../logs/loggers');

const handleErrors = (res, error, operation) => {
  errorLogger.error(`Error ${operation} report: ${error.message}`);
  res.status(500).json({ message: "Internal Server Error" });
};

exports.getReports = async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const { tracker, status, priority } = req.query;

  const filters = {};
  if (tracker) filters.tracker = tracker;
  if (status) filters.status = status;
  if (priority) filters.priority = priority;

  try {
    const reports = await Report.find(filters)
      .skip((page - 1) * limit)
      .limit(limit);

    const totalReports = await Report.countDocuments(filters);

    res.json({
      reports,
      currentPage: page,
      totalPages: Math.max(Math.ceil(totalReports / limit), 1),
      totalReports,
    });
  } catch (error) {
    handleErrors(res, error, "getting");
  }
};

exports.createReport = async (req, res) => {
  try {
    const newReport = new Report(req.body);
    const savedReport = await newReport.save();
    res.json(savedReport);
  } catch (error) {
    handleErrors(res, error, "creating");
  }
};

exports.updateReport = async (req, res) => {
  const reportId = req.params.id;

  try {
    const updatedReport = await Report.findByIdAndUpdate(reportId, req.body, {
      new: true,
    });

    if (!updatedReport) {
      return res.status(404).json({ message: "Report not found" });
    }

    res.json(updatedReport);
  } catch (error) {
    handleErrors(res, error, "updating");
  }
};

exports.deleteReport = async (req, res) => {
  const reportId = req.params.id;

  try {
    const deletedReport = await Report.findByIdAndDelete(reportId);

    if (!deletedReport) {
      return res.status(404).json({ message: "Report not found" });
    }

    res.json({ message: `Report deleted successfully with ID ${reportId}` });
  } catch (error) {
    handleErrors(res, error, "deleting");
  }
};

exports.getReportById = async (req, res) => {
  const reportId = req.params.id;

  try {
    const report = await Report.findById(reportId);

    if (!report) {
      return res.status(404).json({ message: "Report not found" });
    }

    res.json(report);
  } catch (error) {
    handleErrors(res, error, "getting");
  }
};

exports.exportToCSV = async (req, res) => {
  try {
    const reports = await Report.find();

    const csvWriter = createCsvWriter({
      path: "reports.csv",
      header: [
        { id: "tracker", title: "Tracker" },
        { id: "status", title: "Status" },
        { id: "priority", title: "Priority" },
        { id: "subject", title: "Subject" },
        { id: "description", title: "Description" },
        { id: "assignee", title: "Assignee" },
        { id: "startDate", title: "Start Date" },
        { id: "dueDate", title: "Due Date" },
        { id: "updated", title: "Last Updated" },
      ],
    });

    const formattedReports = reports.map((report) => ({
      tracker: report.tracker,
      status: report.status,
      priority: report.priority,
      subject: report.subject,
      description: report.description,
      assignee: report.assignee,
      startDate: report.startDate.toISOString(),
      dueDate: report.dueDate.toISOString(),
      updated: report.updated.toISOString(),
    }));

    await csvWriter.writeRecords(formattedReports);
    res.download("reports.csv");
  } catch (error) {
    handleErrors(res, error, "exporting to CSV");
  }
};

exports.exportToExcel = async (req, res) => {
  try {
    const reports = await Report.find();
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Reports");

    worksheet.columns = [
      { header: "Tracker", key: "tracker" },
      { header: "Status", key: "status" },
      { header: "Priority", key: "priority" },
      { header: "Subject", key: "subject" },
      { header: "Description", key: "description" },
      { header: "Assignee", key: "assignee" },
      { header: "Start Date", key: "startDate" },
      { header: "Due Date", key: "dueDate" },
      { header: "Last Updated", key: "updated" },
    ];

    reports.forEach((report) => {
      worksheet.addRow({
        tracker: report.tracker,
        status: report.status,
        priority: report.priority,
        subject: report.subject,
        description: report.description,
        assignee: report.assignee,
        startDate: report.startDate.toISOString(),
        dueDate: report.dueDate.toISOString(),
        updated: report.updated.toISOString(),
      });
    });

    const filePath = "reports.xlsx";
    await workbook.xlsx.writeFile(filePath);
    res.download(filePath);
  } catch (error) {
    handleErrors(res, error, "exporting to Excel");
  }
};
