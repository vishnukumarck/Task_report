import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AppBar, Toolbar, Button, Typography } from '@mui/material';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { clearToken } from './features/authSlice';
import Login from './components/Login';
import Register from './components/Register';
import Profile from './components/Profile';
import Report from './components/Report';
import ViewAddEditReport from './components/View_Add_Edit_Report';

function App() {
    return (
        <div className="App">
            <BrowserRouter>
                <MainApp />
            </BrowserRouter>
        </div>
    );
}

function MainApp() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleLogout = () => {
        dispatch(clearToken());
        navigate('/login');
    };

    return (
        <>
            <AppBar position="static">
                <Toolbar>
                    <Typography variant="h6" sx={{ flexGrow: 1 }}>
                        Report Management
                    </Typography>
                    <Button color="inherit" component={Link} to="/profile">
                        Profile
                    </Button>
                    <Button color="inherit" component={Link} to="/reports/list">
                        Reports
                    </Button>
                    <Button variant="contained" color="primary" onClick={handleLogout}>
                        Logout
                    </Button>
                </Toolbar>
            </AppBar>

            <Routes>
                <Route path="/" element={<Navigate to="/login" replace />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/reports/list" element={<Report />} />
                <Route path="/reports/create" element={<ViewAddEditReport />} />
                <Route path="/reports/edit/:id" element={<ViewAddEditReport />} />
                <Route path="/reports/view/:id" element={<ViewAddEditReport />} />
            </Routes>
        </>
    );
}

export default App;
