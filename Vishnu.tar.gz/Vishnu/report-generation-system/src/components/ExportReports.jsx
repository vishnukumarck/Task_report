import React from 'react';
import { Button, Grid } from '@mui/material';
import axiosInstance from '../axiosConfig';

const ExportReports = () => {

    const handleDownload = (format) => {
        const url = format === 'csv' ? '/api/reports/export/csv' : '/api/reports/export/excel';
        axiosInstance.get(url, { responseType: 'blob' })
            .then((response) => {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', `reports.${format}`);
                document.body.appendChild(link);
                link.click();
                link.remove();
            })
            .catch((error) => {
                alert(`Error downloading ${format.toUpperCase()} file: ${error.message}`);
            });
    };

    return (
        <Grid container spacing={2} justifyContent="center" style={{ marginTop: '20px' }}>
            <Grid item>
                <Button variant="contained" color="primary" onClick={() => handleDownload('csv')}>
                    Download CSV
                </Button>
            </Grid>
            <Grid item>
                <Button variant="contained" color="secondary" onClick={() => handleDownload('xlsx')}>
                    Download Excel
                </Button>
            </Grid>
        </Grid>
    );
};

export default ExportReports;
