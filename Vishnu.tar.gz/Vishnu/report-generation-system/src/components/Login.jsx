import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { login } from '../features/authSlice';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import {
    Button,
    Typography,
    IconButton,
    InputAdornment,
    FormControl,
    InputLabel,
    OutlinedInput,
    FormHelperText,
    Container
} from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

const Login = () => {
    const [showPassword, setShowPassword] = useState(false);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const status = useSelector((state) => state.auth.status);
    const error = useSelector((state) => state.auth.error);

    const handlePasswordToggle = () => {
        setShowPassword(!showPassword);
    };

    const validationSchema = Yup.object({
        username: Yup.string().required('Username is required'),
        password: Yup.string().required('Password is required'),
    });

    return (
        <Container>
            <Formik
                initialValues={{ username: '', password: '' }}
                validationSchema={validationSchema}
                onSubmit={(values, { setSubmitting }) => {
                    dispatch(login(values))
                        .unwrap()
                        .then(() => {
                            navigate('/reports/list');
                        })
                        .catch((err) => {
                            console.log(err);
                        })
                        .finally(() => {
                            setSubmitting(false);
                        });
                }}
            >
                {({ isSubmitting, handleChange, values }) => (
                    <Form>
                        <Typography variant="h6" gutterBottom>
                            Login
                        </Typography>
                        <FormControl fullWidth margin="normal" variant="outlined">
                            <InputLabel htmlFor="username">Username</InputLabel>
                            <Field
                                as={OutlinedInput}
                                id="username"
                                name="username"
                                type="text"
                                value={values.username}
                                onChange={handleChange}
                                label="Username"
                            />
                            <ErrorMessage name="username" component={FormHelperText} error />
                        </FormControl>
                        <FormControl fullWidth margin="normal" variant="outlined">
                            <InputLabel htmlFor="password">Password</InputLabel>
                            <Field
                                as={OutlinedInput}
                                id="password"
                                name="password"
                                type={showPassword ? 'text' : 'password'}
                                value={values.password}
                                onChange={handleChange}
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton
                                            aria-label="toggle password visibility"
                                            onClick={handlePasswordToggle}
                                            edge="end"
                                        >
                                            {showPassword ? <Visibility /> : <VisibilityOff />}
                                        </IconButton>
                                    </InputAdornment>
                                }
                                label="Password"
                            />
                            <ErrorMessage name="password" component={FormHelperText} error />
                        </FormControl>
                        <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            disabled={isSubmitting || status === 'loading'}
                        >
                            {isSubmitting || status === 'loading' ? 'Logging in...' : 'Login'}
                        </Button>
                        {error && <Typography color="error">{error}</Typography>}
                        <Typography variant="body2" gutterBottom>
                            Don't have an account? <Link to="/register">Register</Link>
                        </Typography>
                    </Form>
                )}
            </Formik>
        </Container>
    );
};

export default Login;
