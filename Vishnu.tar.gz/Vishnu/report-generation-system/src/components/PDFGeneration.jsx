import React from 'react';
import jsPDF from 'jspdf';
import { Button } from '@mui/material';

const PDFGeneration = ({ reportData }) => {
  const handleDownloadPDF = () => {
    const doc = new jsPDF();

    doc.setFontSize(16);
    doc.text('Report Details', 20, 20);

    doc.setFontSize(12);
    doc.text(`Tracker: ${reportData?.tracker}`, 20, 40);
    doc.text(`Status: ${reportData?.status}`, 20, 50);
    doc.text(`Priority: ${reportData?.priority}`, 20, 60);
    doc.text(`Subject: ${reportData?.subject}`, 20, 70);
    doc.text(`Description: ${reportData?.description}`, 20, 80);
    doc.text(`Assignee: ${reportData?.assignee}`, 20, 90);
    doc.text(`Start Date: ${reportData?.startDate}`, 20, 100);
    doc.text(`Due Date: ${reportData?.dueDate}`, 20, 110);

    doc.save('report-details.pdf');
  };

  return (
    <div className="text-center">
      <Button variant="contained" color="primary" onClick={handleDownloadPDF}>
        Download PDF
      </Button>
    </div>
  );
};

export default PDFGeneration;
