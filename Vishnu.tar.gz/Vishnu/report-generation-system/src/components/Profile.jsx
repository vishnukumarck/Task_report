import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../axiosConfig';

const Profile = () => {
    const [user, setUser] = useState(null);
    const token = useSelector((state) => state.auth.token);
    const navigate = useNavigate();

    useEffect(() => {
        if (!token) {
            navigate('/login');
        } else {
            axiosInstance.get('/api/auth/getUserDetails')
                .then((response) => {
                    console.log(response.data);
                    setUser(response.data);
                })
                .catch((error) => {
                    console.error('Error fetching user data:', error);
                    navigate('/login');
                });
        }
    }, [token, navigate]);

    return (
        <div>
            <Typography variant="h4" align="center">Profile</Typography>
            {user ? (
                <div>
                    <Typography variant="h6">Welcome, {user.username}!</Typography>
                    <Typography variant="body1">User ID: {user._id}</Typography>
                    <Typography variant="body1">Email: {user.email}</Typography>
                </div>
            ) : (
                <Typography variant="body1">Loading...</Typography>
            )}
        </div>
    );
};

export default Profile;
