import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const login = createAsyncThunk(
    'auth/login',
    async ({ username, password }, { rejectWithValue }) => {
        try {
            const response = await axios.post(`${process.env.REACT_APP_BASE_URL}/api/auth/login`, { username, password });
            return response.data.token;
        } catch (error) {
            return rejectWithValue(error.response.data.error);
        }
    }
);

export const register = createAsyncThunk(
    'auth/register',
    async ({ username, password, email }, { rejectWithValue, dispatch }) => {
        try {
            await axios.post(`${process.env.REACT_APP_BASE_URL}/api/auth/register`, { username, password, email });
            const response = await dispatch(login({ username, password }));
            return response.payload;
        } catch (error) {
            return rejectWithValue(error.response.data.error);
        }
    }
);

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        token: localStorage.getItem('token') || null,
        status: 'idle',
        error: null,
    },
    reducers: {
        clearToken(state) {
            state.token = null;
            localStorage.removeItem('token');
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(login.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(login.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.token = action.payload;
                localStorage.setItem('token', action.payload);
            })
            .addCase(login.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            })
            .addCase(register.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(register.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.token = action.payload;
                localStorage.setItem('token', action.payload);
            })
            .addCase(register.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            });
    },
});

export const { clearToken } = authSlice.actions;

export default authSlice.reducer;
