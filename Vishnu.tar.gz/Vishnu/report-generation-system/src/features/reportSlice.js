import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../axiosConfig';

export const fetchReports = createAsyncThunk(
    'reports/fetchReports',
    async ({ page, limit }) => {
        const response = await axiosInstance.get(`/api/reports?page=${page}&limit=${limit}`);
        return response.data;
    }
);

export const fetchReportById = createAsyncThunk(
    'reports/fetchReportById',
    async (id) => {
        const response = await axiosInstance.get(`/api/reports/${id}`);
        return response.data;
    }
);

export const createReport = createAsyncThunk(
    'reports/createReport',
    async (report) => {
        const response = await axiosInstance.post('/api/reports', report);
        return response.data;
    }
);

export const updateReport = createAsyncThunk(
    'reports/updateReport',
    async (report) => {
        const response = await axiosInstance.put(`/api/reports/${report.id}`, report);
        return response.data;
    }
);

export const deleteReport = createAsyncThunk(
    'reports/deleteReport',
    async (id) => {
        const response = await axiosInstance.delete(`/api/reports/${id}`);
        return { id, message: response.data.message };
    }
);

const reportSlice = createSlice({
    name: 'reports',
    initialState: {
        reports: [],
        status: 'idle',
        error: null,
        selectedReport: null,
    },
    reducers: {
        // selectedReportId: (state, action) => {
        //     state.selectedReportId = action.payload;
        // },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchReports.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchReports.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.reports = action.payload.reports;
            })
            .addCase(fetchReports.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(fetchReportById.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchReportById.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.selectedReport = action.payload;
            })
            .addCase(fetchReportById.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(createReport.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(createReport.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.reports.push(action.payload);
            })
            .addCase(createReport.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(updateReport.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(updateReport.fulfilled, (state, action) => {
                state.status = 'succeeded';
                const index = state.reports.findIndex(report => report._id === action.payload._id);
                if (index !== -1) {
                    state.reports[index] = action.payload;
                }
            })
            .addCase(updateReport.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(deleteReport.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(deleteReport.fulfilled, (state, action) => {
                state.reports = state.reports.filter(
                    (report) => report._id !== action.payload.id
                );
                state.status = 'succeeded';
            })
            .addCase(deleteReport.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            });
    },
});

// export const { selectedReportId } = reportSlice.actions;

export default reportSlice.reducer;
