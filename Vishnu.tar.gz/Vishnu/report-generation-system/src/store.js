import { configureStore } from '@reduxjs/toolkit';
import authReducer from './features/authSlice';
import reportReducer from './features/reportSlice';

export const store = configureStore({
    reducer: {
        auth: authReducer,
        report: reportReducer,
    },
});
