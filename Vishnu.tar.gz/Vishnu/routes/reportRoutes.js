const express = require('express');
const { createReport, getReports, updateReport, deleteReport, getReportById, exportToCSV, exportToExcel } = require('../controllers/reportController');
const authenticateToken = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/', authenticateToken, createReport);
router.get('/', authenticateToken, getReports);
router.get('/:id', authenticateToken, getReportById);
router.put('/:id', authenticateToken, updateReport);
router.delete('/:id', authenticateToken, deleteReport);
router.get('/export/csv', authenticateToken, exportToCSV);
router.get('/export/excel', authenticateToken, exportToExcel);

module.exports = router;
