const cron = require('node-cron');
const Report = require('../models/Report');
const ExcelJS = require('exceljs');
const path = require('path');

const generateReport = async () => {
  try {
    const reports = await Report.find();

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Scheduled Reports');

    worksheet.columns = [
      { header: 'Tracker', key: 'tracker' },
      { header: 'Status', key: 'status' },
      { header: 'Priority', key: 'priority' },
      { header: 'Subject', key: 'subject' },
      { header: 'Description', key: 'description' },
      { header: 'Assignee', key: 'assignee' },
      { header: 'Start Date', key: 'startDate' },
      { header: 'Due Date', key: 'dueDate' },
      { header: 'Last Updated', key: 'updated' },
    ];

    reports.forEach(report => {
      worksheet.addRow({
        tracker: report.tracker,
        status: report.status,
        priority: report.priority,
        subject: report.subject,
        description: report.description,
        assignee: report.assignee,
        startDate: report.startDate.toISOString(),
        dueDate: report.dueDate.toISOString(),
        updated: report.updated.toISOString(),
      });
    });

    const filePath = path.join(__dirname, '../reports/scheduled_reports.xlsx');

    await workbook.xlsx.writeFile(filePath);
    console.log('Scheduled report generated successfully');
  } catch (error) {
    console.error('Error generating scheduled report:', error);
  }
};

exports.start = () => {
  // cron.schedule('0 0 * * *', generateReport);
  // console.log('Cron job for generating reports is scheduled to run at midnight daily');
  cron.schedule('* * * * *', generateReport);
  console.log('Cron job for generating reports is scheduledto run every 1 minute');
};
