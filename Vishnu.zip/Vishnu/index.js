const express = require("express");
const connectDB = require("./config/db");
const cors = require("cors");
const morgan = require("morgan");
const app = express();
const { logger, errorLogger } = require("./logs/loggers");
const reportRoutes = require("./routes/reportRoutes");
const authRoutes = require("./routes/authRoutes");
const cronJobs = require("./cron/cronJobs");

require("dotenv").config();

connectDB();

// app.use(morgan('tiny'));
app.use(
  morgan("combined", {
    stream: { write: (message) => logger.info(message.trim()) },
  })
);

var corsOptions = {
  origin: "http://localhost:3000",
  // origin: ["http://localhost:3000", "http://localhost:3001"]
};

app.use(cors(corsOptions));

app.use(express.json());

app.get("/", (req, res) => {
  res.json({ message: "Report Generation System." });
});

app.use("/api/reports", reportRoutes);
app.use("/api/auth", authRoutes);

cronJobs.start();

app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  console.error(err.message, err.stack);
  errorLogger.error(`Error handler middleware: ${err.message}`);
  res.status(statusCode).json({ message: err.message });
  return;
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  logger.info(`Server is running on port ${PORT}.`);
});
