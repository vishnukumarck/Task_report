const mongoose = require("mongoose");

const reportSchema = new mongoose.Schema(
    {
        tracker: {
            type: String,
            enum: ['Bug', 'Feature', 'Support'],
            required: true,
        },
        status: {
            type: String,
            enum: ['New', 'Resolved', 'InProgress', 'Feedback'],
            required: true,
        },
        priority: {
            type: String,
            enum: ['Low', 'Normal', 'High', 'Urgent', 'Immediate'],
            required: true,
        },
        subject: {
            type: String,
            required: true,
        },
        description: {
            type: String,
            required: true,
        },
        assignee: {
            type: String,
            required: true,
        },
        startDate: {
            type: Date,
            required: true,
        },
        dueDate: {
            type: Date,
            required: true,
        },
        updated: {
            type: Date,
            required: true,
        },
    }
);

module.exports = mongoose.model("Report", reportSchema);
