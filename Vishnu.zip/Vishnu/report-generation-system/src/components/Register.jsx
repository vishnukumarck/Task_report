import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { register } from '../features/authSlice';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import {
    Button,
    Typography,
    IconButton,
    InputAdornment,
    FormControl,
    InputLabel,
    OutlinedInput,
    FormHelperText,
    Container
} from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

const Register = () => {
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const status = useSelector((state) => state.auth.status);
    const error = useSelector((state) => state.auth.error);

    const handlePasswordToggle = () => {
        setShowPassword(!showPassword);
    };

    const handleConfirmPasswordToggle = () => {
        setShowConfirmPassword(!showConfirmPassword);
    };

    const validationSchema = Yup.object({
        username: Yup.string().required('Username is required'),
        email: Yup.string().email('Invalid email address').required('Email is required'),
        password: Yup.string()
            .min(6, 'Password must be at least 6 characters')
            .max(12, 'Password cannot exceed 12 characters')
            .matches(
                /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{6,12}$/, 
                'Password must include at least one letter, one number, and one special character'
            )
            .required('Password is required'),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
            .required('Confirm Password is required'),
    });

    return (
        <Container>
            <Formik
                initialValues={{
                    username: '',
                    password: '',
                    confirmPassword: '',
                    email: '',
                }}
                validationSchema={validationSchema}
                onSubmit={(values, { setSubmitting }) => {
                    dispatch(register(values))
                        .unwrap()
                        .then(() => {
                            navigate('/login');
                        })
                        .catch((err) => {
                            console.log(err);
                        })
                        .finally(() => {
                            setSubmitting(false);
                        });
                }}
            >
                {({ isSubmitting, handleChange, values }) => (
                    <Form>
                        <Typography variant="h6" gutterBottom>
                            Register
                        </Typography>
                        <FormControl fullWidth margin="normal" variant="outlined">
                            <InputLabel htmlFor="username">Username</InputLabel>
                            <Field
                                as={OutlinedInput}
                                id="username"
                                name="username"
                                value={values.username}
                                onChange={handleChange}
                                label="Username"
                            />
                            <ErrorMessage name="username" component={FormHelperText} error />
                        </FormControl>
                        <FormControl fullWidth margin="normal" variant="outlined">
                            <InputLabel htmlFor="password">Password</InputLabel>
                            <Field
                                as={OutlinedInput}
                                id="password"
                                name="password"
                                type={showPassword ? 'text' : 'password'}
                                value={values.password}
                                onChange={handleChange}
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton
                                            aria-label="toggle password visibility"
                                            onClick={handlePasswordToggle}
                                            edge="end"
                                        >
                                            {showPassword ? <Visibility /> : <VisibilityOff />}
                                        </IconButton>
                                    </InputAdornment>
                                }
                                label="Password"
                            />
                            <ErrorMessage name="password" component={FormHelperText} error />
                        </FormControl>
                        <FormControl fullWidth margin="normal" variant="outlined">
                            <InputLabel htmlFor="confirm-password">Confirm Password</InputLabel>
                            <Field
                                as={OutlinedInput}
                                id="confirm-password"
                                name="confirmPassword"
                                type={showConfirmPassword ? 'text' : 'password'}
                                value={values.confirmPassword}
                                onChange={handleChange}
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton
                                            aria-label="toggle confirm password visibility"
                                            onClick={handleConfirmPasswordToggle}
                                            edge="end"
                                        >
                                            {showConfirmPassword ? <Visibility /> : <VisibilityOff />}
                                        </IconButton>
                                    </InputAdornment>
                                }
                                label="Confirm Password"
                            />
                            <ErrorMessage name="confirmPassword" component={FormHelperText} error />
                        </FormControl>
                        <FormControl fullWidth margin="normal" variant="outlined">
                            <InputLabel htmlFor="email">Email</InputLabel>
                            <Field
                                as={OutlinedInput}
                                id="email"
                                name="email"
                                type="email"
                                value={values.email}
                                onChange={handleChange}
                                label="Email"
                            />
                            <ErrorMessage name="email" component={FormHelperText} error />
                        </FormControl>
                        <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            disabled={isSubmitting || status === 'loading'}
                        >
                            {isSubmitting || status === 'loading' ? 'Registering...' : 'Register'}
                        </Button>
                        {error && <Typography color="error">{error}</Typography>}
                        <Typography variant="body2" gutterBottom>
                            Already have an account? <Link to="/login">Login</Link>
                        </Typography>
                    </Form>
                )}
            </Formik>
        </Container>
    );
};

export default Register;
