import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchReports, deleteReport } from '../features/reportSlice';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import {
    Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
    Button, Typography, Select, MenuItem, FormControl, InputLabel, Pagination
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import ExportReports from "./ExportReports";
import GeneratePDF from './GeneratePDF';
const Report = () => {
    const dispatch = useDispatch();
    const reports = useSelector((state) => state.report.reports);
    const navigate = useNavigate();
    const [itemsPerPage, setItemsPerPage] = useState(5);
    const itemsPerPageOptions = [3, 5, 10, 15, 20];
    const [currentPage, setCurrentPage] = useState(0);
    const [totalPages, setTotalPages] = useState(1);

    useEffect(() => {
        dispatch(fetchReports({ page: currentPage + 1, limit: itemsPerPage }))
            .unwrap()
            .then((result) => {
                setTotalPages(result.totalPages);
            })
            .catch((error) => {
                console.log(error);
                alert(`Error fetching reports: ${error}`);
            });
    }, [dispatch, currentPage, itemsPerPage]);

    const handleDelete = (id) => {
        const confirmDelete = window.confirm(`Are you sure you want to delete Report with ID ${id}?`);
        if (confirmDelete) {
            dispatch(deleteReport(id))
                .unwrap()
                .then((result) => {
                    alert(`${result.message}`);
                })
                .catch((error) => {
                    alert(`Error deleting report: ${error}`);
                });
        }
    };

    const handleAdd = () => {
        navigate('/reports/create');
    };

    const handleItemsPerPageChange = (e) => {
        const selectedItemsPerPage = e.target.value;
        setItemsPerPage(selectedItemsPerPage);
        // setCurrentPage(0);
    };

    return (
        <div>
            <Typography variant="h4" align="center" gutterBottom>
                Report List
            </Typography>
            <FormControl variant="outlined" size="small" style={{ marginBottom: 20 }}>
                <InputLabel>Items Per Page</InputLabel>
                <Select
                    value={itemsPerPage}
                    onChange={handleItemsPerPageChange}
                    label="Items Per Page"
                >
                    {itemsPerPageOptions.map((option) => (
                        <MenuItem key={option} value={option}>
                            {option}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Tracker</TableCell>
                            <TableCell>Status</TableCell>
                            <TableCell>Priority</TableCell>
                            <TableCell>Subject</TableCell>
                            <TableCell>Assignee</TableCell>
                            <TableCell>Updated</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {reports.map((item) => (
                            <TableRow key={item._id}>
                                <TableCell>{item.tracker}</TableCell>
                                <TableCell>{item.status}</TableCell>
                                <TableCell>{item.priority}</TableCell>
                                <TableCell>{item.subject}</TableCell>
                                <TableCell>{item.assignee}</TableCell>
                                <TableCell>{format(new Date(item.updated), 'dd-MM-yyyy hh:mm:ss a')}</TableCell>
                                <TableCell>
                                    <Button variant="contained" color="info" size="small" onClick={() => navigate(`/reports/view/${item._id}`)}>
                                        View
                                    </Button> &nbsp;
                                    <Button variant="contained" color="primary" size="small" onClick={() => navigate(`/reports/edit/${item._id}`)}>
                                        Edit
                                    </Button> &nbsp;
                                    <Button variant="contained" color="error" size="small" onClick={() => handleDelete(item._id)}>
                                        Delete
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 20 }}>
                <Pagination
                    count={totalPages}
                    page={currentPage + 1}
                    onChange={(event, value) => setCurrentPage(value - 1)}
                    color="primary"
                />
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 20 }}>
                <Button
                    variant="contained"
                    color="primary"
                    startIcon={<AddIcon />}
                    onClick={handleAdd}
                >
                    Add Report
                </Button>
            </div>
            <GeneratePDF />
            <ExportReports />
        </div>
    );
};

export default Report;
