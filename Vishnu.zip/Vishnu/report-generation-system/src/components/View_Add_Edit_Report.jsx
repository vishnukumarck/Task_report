import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import {
  fetchReportById,
  createReport,
  updateReport,
} from "../features/reportSlice";
import {
  Card,
  CardContent,
  Button,
  Grid,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
} from "@mui/material";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { format } from "date-fns";
import PDFGeneration from "./PDFGeneration";
import axiosInstance from "../axiosConfig";

const View_Add_Edit_Report = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const reports = useSelector((state) => state.report.reports);
  const [reportData, setReportData] = useState(null);
  const location = useLocation();
  const currentUrl = location.pathname;
  const [users, setUsers] = useState([]);

  const initialValues = {
    tracker: "",
    status: "",
    priority: "",
    subject: "",
    description: "",
    assignee: "",
    startDate: "",
    dueDate: "",
  };

  const validationSchema = Yup.object().shape({
    tracker: Yup.string().required("Tracker is required"),
    status: Yup.string().required("Status is required"),
    priority: Yup.string().required("Priority is required"),
    subject: Yup.string()
      .min(3, "Minimum 3 characters")
      .max(100, "Maximum 100 characters")
      .required("Subject is required"),
    description: Yup.string()
      .min(10, "Minimum 10 characters")
      .max(500, "Maximum 500 characters")
      .required("Description is required"),
    assignee: Yup.string()
      .min(3, "Minimum 3 characters")
      .max(50, "Maximum 50 characters")
      .required("Assignee is required"),
    startDate: Yup.date().required("Start Date is required"),
    dueDate: Yup.date().required("Due Date is required"),
  });

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get("/api/auth/getAllUsers");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
  }, []);

  useEffect(() => {
    // if (!reports.length) {
    //     dispatch(fetchReports({ page: 0, limit: 0 }));
    // }
    if (id) {
      // const report = reports.find((report) => report._id === id);
      // if (report) {
      //     setReportData({
      //         tracker: report.tracker,
      //         status: report.status,
      //         priority: report.priority,
      //         subject: report.subject,
      //         description: report.description,
      //         assignee: report.assignee,
      //         startDate: format(new Date(report.startDate), 'yyyy-MM-dd'),
      //         dueDate: format(new Date(report.dueDate), 'yyyy-MM-dd'),
      //     });
      // }
      dispatch(fetchReportById(id))
        .unwrap()
        .then((result) => {
          console.log(result);
          setReportData({
            ...result,
            startDate: format(new Date(result.startDate), "yyyy-MM-dd"),
            dueDate: format(new Date(result.dueDate), "yyyy-MM-dd"),
          });
        })
        .catch((error) => {
          console.log(error);
          alert(`Error fetching reports id: ${error}`);
        });
    }
  }, [dispatch, id, reports]);

  const handleSubmit = (values) => {
    if (new Date(values.startDate) > new Date(values.dueDate)) {
      return alert("Start Date must be less than or equal to Due Date");
    }

    const action = id ? updateReport : createReport;
    const updatedValues = {
      ...values,
      updated: format(new Date(), "yyyy-MM-dd HH:mm:ss"),
    };

    if (id) {
      updatedValues.id = id;
    }

    dispatch(action(updatedValues))
      .unwrap()
      .then(() => {
        navigate("/reports/list");
      })
      .catch((error) => {
        alert(`Error ${action}: ${error}`);
      });
  };

  return (
    <>
      {currentUrl.includes("/reports/view/") ? (
        <div className="container col-10">
          <header className="text-center">
            <h2>Report Details</h2>
          </header>
          <br />
          <Card>
            {/* <CardHeader >{reportData?.subject}</CardHeader> */}
            <h3>{reportData?.subject}</h3>
            <CardContent>
              <p>
                <strong>Tracker:</strong> {reportData?.tracker}
              </p>
              <p>
                <strong>Status:</strong> {reportData?.status}
              </p>
              <p>
                <strong>Priority:</strong> {reportData?.priority}
              </p>
              <p>
                <strong>Description:</strong> {reportData?.description}
              </p>
              <p>
                <strong>Assignee:</strong> {reportData?.assignee}
              </p>
              <p>
                <strong>Start Date:</strong> {reportData?.startDate}
              </p>
              <p>
                <strong>Due Date:</strong> {reportData?.dueDate}
              </p>
            </CardContent>

            <Grid
              container
              spacing={2}
              justifyContent="center"
              style={{ marginTop: "20px" }}
            >
              <Grid item>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => navigate("/reports/list")}
                >
                  Back to Report List
                </Button>
              </Grid>
              <Grid item>
                <PDFGeneration reportData={reportData} />
              </Grid>
            </Grid>
          </Card>
        </div>
      ) : (
        <div className="container col-8">
          <header className="text-center">
            <h2>{id ? "Edit" : "Add"} Report</h2>
          </header>
          <br />
          <Formik
            initialValues={reportData || initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ values, handleChange, touched, errors, handleBlur }) => (
              <Form>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      select
                      label="Tracker"
                      name="tracker"
                      value={values.tracker}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.tracker && errors.tracker)}
                      helperText={
                        touched.tracker && errors.tracker ? errors.tracker : ""
                      }
                    >
                      <MenuItem value="Bug">Bug</MenuItem>
                      <MenuItem value="Feature">Feature</MenuItem>
                      <MenuItem value="Support">Support</MenuItem>
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      select
                      label="Status"
                      name="status"
                      value={values.status}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.status && errors.status)}
                      helperText={
                        touched.status && errors.status ? errors.status : ""
                      }
                    >
                      <MenuItem value="New">New</MenuItem>
                      <MenuItem value="Resolved">Resolved</MenuItem>
                      <MenuItem value="InProgress">InProgress</MenuItem>
                      <MenuItem value="Feedback">Feedback</MenuItem>
                    </Field>
                  </Grid>

                  <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      select
                      label="Priority"
                      name="priority"
                      value={values.priority}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.priority && errors.priority)}
                      helperText={
                        touched.priority && errors.priority
                          ? errors.priority
                          : ""
                      }
                    >
                      <MenuItem value="Low">Low</MenuItem>
                      <MenuItem value="Normal">Normal</MenuItem>
                      <MenuItem value="High">High</MenuItem>
                      <MenuItem value="Urgent">Urgent</MenuItem>
                      <MenuItem value="Immediate">Immediate</MenuItem>
                    </Field>
                  </Grid>

                  {/* <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      label="Assignee"
                      name="assignee"
                      value={values.assignee}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.assignee && errors.assignee)}
                      helperText={
                        touched.assignee && errors.assignee
                          ? errors.assignee
                          : ""
                      }
                    />
                  </Grid> */}

                  <Grid item xs={12} sm={6}>
                    <FormControl fullWidth variant="outlined" size="small">
                      <InputLabel>Assignee</InputLabel>
                      <Select
                        label="Assignee"
                        name="assignee"
                        value={values.assignee}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={!!(touched.assignee && errors.assignee)}
                      >
                        {users.map((user) => (
                          <MenuItem key={user._id} value={user.username}>
                            {user.username}
                          </MenuItem>
                        ))}
                      </Select>
                      {touched.assignee && errors.assignee && (
                        <div style={{ color: "red" }}>{errors.assignee}</div>
                      )}
                    </FormControl>
                  </Grid>

                  <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      type="date"
                      label="Start Date"
                      name="startDate"
                      InputLabelProps={{ shrink: true }}
                      value={values.startDate}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.startDate && errors.startDate)}
                      helperText={
                        touched.startDate && errors.startDate
                          ? errors.startDate
                          : ""
                      }
                    />
                  </Grid>

                  <Grid item xs={12} sm={6}>
                    <Field
                      as={TextField}
                      fullWidth
                      type="date"
                      label="Due Date"
                      name="dueDate"
                      InputLabelProps={{ shrink: true }}
                      value={values.dueDate}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.dueDate && errors.dueDate)}
                      helperText={
                        touched.dueDate && errors.dueDate ? errors.dueDate : ""
                      }
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <Field
                      as={TextField}
                      fullWidth
                      label="Subject"
                      name="subject"
                      value={values.subject}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.subject && errors.subject)}
                      helperText={
                        touched.subject && errors.subject ? errors.subject : ""
                      }
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <Field
                      as={TextField}
                      fullWidth
                      multiline
                      rows={4}
                      label="Description"
                      name="description"
                      value={values.description}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!(touched.description && errors.description)}
                      helperText={
                        touched.description && errors.description
                          ? errors.description
                          : ""
                      }
                    />
                  </Grid>
                </Grid>
                <br />
                <div className="text-center">
                  <Button type="submit" variant="contained" color="success">
                    Save
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      )}
    </>
  );
};

export default View_Add_Edit_Report;
