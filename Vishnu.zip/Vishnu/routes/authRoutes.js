const express = require('express');
const { register, login, getUserDetails, getAllUsers } = require('../controllers/authController');
const authenticateToken = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/getUserDetails', authenticateToken, getUserDetails);
router.get("/getAllUsers", authenticateToken, getAllUsers);

module.exports = router;
